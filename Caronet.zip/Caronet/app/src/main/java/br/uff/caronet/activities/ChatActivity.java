package br.uff.caronet.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import br.uff.caronet.R;

public class ChatActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
    }
}
