package br.uff.caronet.models;

public class Campi {

    private String name;

    public Campi(String name) {
        this.name = name;
    }

    public Campi() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
